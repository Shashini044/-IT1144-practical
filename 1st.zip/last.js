/*document.getElementById("ColorBtn").addEventListener("click",function(){
	document.body.style.backgroundColor="skyblue";

});
document.getElementById("colorBtn").addEventListener("click",function(){
	document.body.style.backgroundColor="lightblue";
	this.style.backgroundColor="red";
	document.getElementById("myPara").style.color="red";
	});
document.getElementById("colorBtn").addEventListener("click" ,function(){
	document.body.style.backgroundColor="skyblue";
	this.style.backgroundColor="blue";
// }); */

document.getElementById("colorBtn").addEventListener("click",function(){
	document.body.style.backgroundColor="skyblue";
	document.getElementById("myPara").style.color="blue";
	this.style.backgroundColor="pink";

});