/*document.getElementById("ColorBtm").addEventListener("click",function(){
	document.body.style.backgroundColor="lightblue"
});

document.getElementById("myPara").addEventListener("click",function(){
	document.myPara.style.Color="green"
});

    document.getElementById("ColorBtm").addEventListener("click",function(){
	document.body.style.backgroundColor="lightblue";
	this.style.backgroundColor="pink";
    document.getElementById("myPara").style.color="purple"
});




	document.getElementById("ColorBtm1").addEventListener("click",function(){
	document.body.style.backgroundColor="yellow"	
	this.style.backgroundColor="skyblue";
	document.getElementById("myPara").style.color="red"
	});
	

function showDetails(){
	let name=document.getElementById("name").value;
	document.getElementById("result").innerText="Hello"+name;
}
*/

function buy(product){
	alert(product+"  selected");}

function great(){
	alert("HELLO");
}